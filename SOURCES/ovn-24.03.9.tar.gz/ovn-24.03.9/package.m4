# Signature of the current package.
m4_define([AT_PACKAGE_NAME],      [ovn])
m4_define([AT_PACKAGE_TARNAME],   [ovn])
m4_define([AT_PACKAGE_VERSION],   [24.03.9])
m4_define([AT_PACKAGE_STRING],    [ovn 24.03.9])
m4_define([AT_PACKAGE_BUGREPORT], [bugs@openvswitch.org])
