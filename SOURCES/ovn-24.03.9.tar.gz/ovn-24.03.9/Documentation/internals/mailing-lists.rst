..
      Licensed under the Apache License, Version 2.0 (the "License"); you may
      not use this file except in compliance with the License. You may obtain
      a copy of the License at

          http://www.apache.org/licenses/LICENSE-2.0

      Unless required by applicable law or agreed to in writing, software
      distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
      WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
      License for the specific language governing permissions and limitations
      under the License.

      Convention for heading levels in OVN documentation:

      =======  Heading 0 (reserved for the title in a document)
      -------  Heading 1
      ~~~~~~~  Heading 2
      +++++++  Heading 3
      '''''''  Heading 4

      Avoid deeper levels because they do not render well.

=============
Mailing Lists
=============

.. important::
   Report security issues **only** to security@openvswitch.org. For more
   information, refer to our :doc:`security policies <security>`.

ovs-announce
------------

The `ovs-announce`__ mailing list is used to announce new versions of
Open vSwitch and OVN and is extremely low-volume. `(subscribe)`__
`(archives)`__

__ ovs-announce@openvswitch.org
__ https://mail.openvswitch.org/mailman/listinfo/ovs-announce/
__ https://mail.openvswitch.org/pipermail/ovs-announce/

ovs-discuss
-----------

The `ovs-discuss`__ mailing list is used to discuss plans and design decisions
for Open vSwitch and OVN. It is also an appropriate place for user questions.
`(subscribe)`__ `(archives)`__

__ ovs-discuss@openvswitch.org
__ https://mail.openvswitch.org/mailman/listinfo/ovs-discuss/
__ https://mail.openvswitch.org/pipermail/ovs-discuss/

ovs-dev
-------

The `ovs-dev`__ mailing list is used to discuss development and review code
before being committed. `(subscribe)`__ `(archives)`__

__ ovs-dev@openvswitch.org
__ https://mail.openvswitch.org/mailman/listinfo/ovs-dev/
__ https://mail.openvswitch.org/pipermail/ovs-dev/

bugs
-----

The `bugs`__ mailing list is an alias for the discuss mailing list.

__ bugs@openvswitch.org

security
--------

The `security`__ mailing list is for submitting security vulnerabilities to the
security team.

__ security@openvswitch.org
