# Signature of the current package.
m4_define([AT_PACKAGE_NAME],      [openvswitch])
m4_define([AT_PACKAGE_TARNAME],   [openvswitch])
m4_define([AT_PACKAGE_VERSION],   [3.3.8])
m4_define([AT_PACKAGE_STRING],    [openvswitch 3.3.8])
m4_define([AT_PACKAGE_BUGREPORT], [bugs@openvswitch.org])
