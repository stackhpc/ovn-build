netcfg -u OVSExt
